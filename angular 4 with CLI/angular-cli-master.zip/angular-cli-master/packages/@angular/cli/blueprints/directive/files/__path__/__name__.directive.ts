import { Directive } from '@angular/core';

@Directive({
  selector: '[<%= selector %>]'
})
export class <%= classifiedModuleName %>Directive {

  constructor() { }

}
