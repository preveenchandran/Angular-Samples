/*eslint-disable no-console */
'use strict';
require('../lib/bootstrap-local');
require('./e2e_runner.ts');
